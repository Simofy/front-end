  Requirements

Node.js https://nodejs.org/en/download/

  Prerequisites ( install gulp globally)
  
npm install
npm install gulp -g

  Start

gulp serve